import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Mail, ExternalLink } from "lucide-react";
import { useState } from "react";

/**
 * Design Philosophy: Minimalist & Contemporary
 * - Clean off-white background with deep indigo accents
 * - Playfair Display for elegant headlines
 * - Masonry gallery layout with smooth animations
 * - Focus on artwork as the primary visual element
 */

export default function Home() {
  const [activeTab, setActiveTab] = useState<"portfolio" | "toolkit">("portfolio");

  const artworks = [
    {
      id: 1,
      title: "Abstract Watercolor",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663558458853/Y3EazX3eg8BRthXbjMw6oS/gallery_artwork_1-ZD5zTtwXnipPrQQ4E3iAZv.webp",
      category: "Abstract",
    },
    {
      id: 2,
      title: "Portrait Study",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663558458853/Y3EazX3eg8BRthXbjMw6oS/gallery_artwork_2-Xxj6YyEzyccmYmRo693ene.webp",
      category: "Portrait",
    },
    {
      id: 3,
      title: "Landscape Drawing",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663558458853/Y3EazX3eg8BRthXbjMw6oS/gallery_artwork_3-kKxTj5UKVSpke7KPn9dqs5.webp",
      category: "Landscape",
    },
  ];

  const postTemplates = [
    {
      id: 1,
      title: "Behind the Scenes",
      description: "Show your creative process with step-by-step artwork development",
      color: "bg-blue-50",
    },
    {
      id: 2,
      title: "Interactive Poll",
      description: "Engage your audience with 'Choose Your Favorite' style posts",
      color: "bg-indigo-50",
    },
    {
      id: 3,
      title: "Commission Spotlight",
      description: "Showcase completed commissions and attract new customers",
      color: "bg-purple-50",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-sm"></div>
            <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-primary">Art Portfolio</h1>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab("portfolio")}
              className={`font-medium transition-colors ${
                activeTab === "portfolio"
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Portfolio
            </button>
            <button
              onClick={() => setActiveTab("toolkit")}
              className={`font-medium transition-colors ${
                activeTab === "toolkit"
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Toolkit
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="space-y-3">
                <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                  Showcase Your
                  <span className="text-primary"> Artistic Vision</span>
                </h1>
                <p className="text-lg text-muted-foreground max-w-lg">
                  A professional portfolio platform designed for artists. Display your work, attract commissions, and grow your audience with proven social media strategies.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Get Started <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-border hover:bg-secondary"
                >
                  Learn More
                </Button>
              </div>
            </div>
            <div className="relative h-96 md:h-full">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663558458853/Y3EazX3eg8BRthXbjMw6oS/hero_art_portfolio-YE3Gs6QQ2F7mT72eZ6oozo.webp"
                alt="Artist Studio"
                className="w-full h-full object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      {activeTab === "portfolio" && (
        <>
          <section className="py-16 md:py-24 bg-secondary/30">
            <div className="container">
              <div className="text-center mb-12">
                <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                  Featured Artworks
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Explore a curated selection of contemporary drawings and paintings
                </p>
              </div>

              {/* Gallery Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {artworks.map((artwork, index) => (
                  <div
                    key={artwork.id}
                    className="group cursor-pointer"
                    style={{
                      animation: `fadeInUp 0.6s ease-out ${index * 0.1}s both`,
                    }}
                  >
                    <Card className="overflow-hidden bg-card hover:shadow-xl transition-all duration-300">
                      <div className="relative h-80 overflow-hidden bg-muted">
                        <img
                          src={artwork.image}
                          alt={artwork.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>
                      </div>
                      <div className="p-6">
                        <div className="text-sm text-primary font-medium mb-2">
                          {artwork.category}
                        </div>
                        <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-foreground">
                          {artwork.title}
                        </h3>
                      </div>
                    </Card>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Commission Section */}
          <section className="py-16 md:py-24">
            <div className="container">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl md:text-5xl font-bold text-foreground">
                    Custom Commissions
                  </h2>
                  <p className="text-lg text-muted-foreground">
                    Bring your vision to life with personalized artwork. Whether you're looking for a portrait, landscape, or abstract piece, I work closely with clients to create unique, meaningful art.
                  </p>
                  <ul className="space-y-3">
                    {["Custom portraits & character designs", "Landscape & nature drawings", "Abstract & experimental work"].map(
                      (item, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-1">
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                          </div>
                          <span className="text-foreground">{item}</span>
                        </li>
                      )
                    )}
                  </ul>
                  <Button
                    size="lg"
                    className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto"
                  >
                    <Mail className="mr-2 w-4 h-4" />
                    Request a Commission
                  </Button>
                </div>
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg p-8 border border-border">
                  <div className="space-y-6">
                    <div>
                      <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-foreground mb-2">
                        How It Works
                      </h3>
                      <p className="text-muted-foreground">
                        Simple, transparent process from concept to completion
                      </p>
                    </div>
                    {[
                      { step: "1", title: "Consultation", desc: "Discuss your ideas and vision" },
                      { step: "2", title: "Proposal", desc: "Receive a detailed quote and timeline" },
                      { step: "3", title: "Creation", desc: "I bring your vision to life" },
                      { step: "4", title: "Delivery", desc: "Receive your finished artwork" },
                    ].map((item) => (
                      <div key={item.step} className="flex gap-4">
                        <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                          {item.step}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>
        </>
      )}

      {/* Social Media Toolkit */}
      {activeTab === "toolkit" && (
        <section className="py-16 md:py-24 bg-secondary/30">
          <div className="container">
            <div className="text-center mb-12">
              <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Social Media Toolkit
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Proven strategies and post templates to grow your art page and attract customers
              </p>
            </div>

            {/* Post Templates */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              {postTemplates.map((template) => (
                <Card
                  key={template.id}
                  className="overflow-hidden bg-card hover:shadow-lg transition-all duration-300"
                >
                  <div className={`h-32 ${template.color}`}></div>
                  <div className="p-6">
                    <h3 className="font-display text-xl font-bold text-foreground mb-2">
                      {template.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">{template.description}</p>
                    <Button
                      variant="ghost"
                      className="text-primary hover:text-primary/80 p-0 h-auto"
                    >
                      View Template <ExternalLink className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Strategy Guide */}
            <Card className="bg-card p-8 md:p-12">
              <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-foreground mb-6">
                Complete Strategy Guide
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="font-semibold text-foreground">Key Content Pillars</h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Behind-the-scenes process videos</li>
                    <li>• Finished artwork showcases</li>
                    <li>• Interactive polls and engagement posts</li>
                    <li>• Educational & inspirational content</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="font-semibold text-foreground">Conversion Strategies</h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Clear calls-to-action on every post</li>
                    <li>• Commission spotlight features</li>
                    <li>• Community engagement tactics</li>
                    <li>• Consistent posting schedule</li>
                  </ul>
                </div>
              </div>
              <Button
                className="mt-8 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Download Full Guide
              </Button>
            </Card>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-4xl md:text-5xl font-bold mb-4">
            Ready to Showcase Your Art?
          </h2>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto mb-8">
            Start your journey as a professional artist today. Build your portfolio, attract commissions, and grow your audience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90"
            >
              Get Started Now
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
            >
              Contact Me
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary/50 border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="font-bold text-foreground mb-4">Art Portfolio</h3>
              <p className="text-sm text-muted-foreground">
                Showcasing contemporary art and connecting artists with collectors.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Portfolio</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Gallery</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Commissions</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">About</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Toolkit</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Instagram</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Facebook</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Email</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Art Portfolio Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
